package com.example.autogg;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

@Environment(EnvType.CLIENT)
public class AutoGG implements ClientModInitializer {

    public static final String MOD_ID = "autogg";
    
    private static boolean enabled = true;
    private static long lastTriggerTime = 0;
    private static KeyBinding toggleKey;

    @Override
    public void onInitializeClient() {
        // Регистрируем кнопку G для включения/выключения
        KeyBinding.Category category = KeyBinding.Category.create(
                Identifier.of(MOD_ID, "main")
        );

        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.autogg.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_G, // Кнопка G по умолчанию
                category
        ));

        // Обработка нажатия кнопки
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                enabled = !enabled;
                if (client.player != null) {
                    Text msg = Text.literal("[AutoGG] ").formatted(Formatting.AQUA)
                            .append(Text.literal(enabled ? "Вкл" : "Выкл")
                                    .formatted(enabled ? Formatting.GREEN : Formatting.RED));
                    client.player.sendMessage(msg, false);
                }
            }
        });

        // Обработка чата
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (!enabled) return;

            String text = message.getString();

            // Проверяем все триггеры
            boolean triggered = text.contains("Match Complete") 
                             || text.contains("Match Results") 
                             || text.contains("Победа за");

            if (triggered) {
                long now = System.currentTimeMillis();
                
                // Защита от спама (3 секунды)
                if (now - lastTriggerTime > 3000) {
                    lastTriggerTime = now;
                    
                    MinecraftClient client = MinecraftClient.getInstance();
                    if (client.player != null && client.player.networkHandler != null) {
                        client.player.networkHandler.sendChatMessage("gg");
                    }
                }
            }
        });
    }
}